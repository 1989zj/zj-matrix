---
name: auto-drama-api-pipeline
description: 工业级纯代码驱动的 AI 短剧全自动生产流水线。整合 LLM (剧本) + 阿里百炼 CosyVoice (配音) + 国内版可灵 Kling (视频生成) + Creatomate (云端剪辑合成)，包含经过实战验证的 API 避坑指南。
---

# Auto Drama API Pipeline (工业级短剧全自动流水线)

这是一个纯代码驱动的“工业级”工作流，摒弃所有图形化编辑软件，通过 API 将短剧创作的核心环节（剧本、语音、画面、剪辑）串联起来。

根据实战测试，**强推使用国内版“可灵 API”配合“阿里百炼 CosyVoice SDK”**，以规避海外工具严格的免费层风控机制。

## 🎯 核心架构与 API 选型

1. **大脑 (LLM API)**: GPT-4o / Claude 3.5。生成包含 `visual_prompt` 和 `dialogue` 的 JSON 分镜。
2. **声音 (阿里百炼 CosyVoice)**: 国内最佳平替，使用官方 `dashscope` SDK，情绪饱满（如 `longxiaochun` 音色）。弃用 ElevenLabs 免费层以防云端风控。
3. **视觉 (可灵 Kling 国内版)**: 极具性价比与视觉张力，采用 AK/SK 生成 JWT 的鉴权方式。
4. **合成 (Creatomate API)**: 接收 JSON Payload 自动将生成的音视频对齐渲染。

## ⚙️ 环境变量准备

```bash
export KLING_AK="xxx"
export KLING_SK="xxx"
export ALIYUN_API_KEY="sk-xxx"
export CREATOMATE_API_KEY="xxx"
```

## 🚀 核心调度代码示例 (实战验证版)

```python
import os
import time
import requests
import jwt
import dashscope
from dashscope.audio.tts_v2 import SpeechSynthesizer

KLING_AK = os.getenv("KLING_AK")
KLING_SK = os.getenv("KLING_SK")
dashscope.api_key = os.getenv("ALIYUN_API_KEY")
CREATOMATE_KEY = os.getenv("CREATOMATE_API_KEY")

# 1. 可灵国内版 JWT 鉴权
def get_kling_token():
    payload = {
        "iss": KLING_AK,
        "exp": int(time.time()) + 1800,
        "nbf": int(time.time()) - 5
    }
    return jwt.encode(payload, KLING_SK, algorithm="HS256", headers={"alg": "HS256", "typ": "JWT"})

# 2. 提交可灵视频生成任务
def generate_video(prompt):
    url = "https://openapi.klingai.com/v1/videos/text2video"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {get_kling_token()}"
    }
    data = {
        "model_name": "kling-v1", # 避坑: kling-v1-5 可能不支持 mode: std
        "prompt": prompt,
        "mode": "std",
        "duration": "5",
        "ratio": "9:16"
    }
    res = requests.post(url, headers=headers, json=data)
    if res.status_code == 200:
        return res.json()['data']['task_id']
    return None

# 3. 阿里云 CosyVoice 配音 (必须用SDK)
def generate_audio(text, output_path):
    synthesizer = SpeechSynthesizer(model="cosyvoice-v1", voice="longxiaochun")
    audio_data = synthesizer.call(text)
    with open(output_path, 'wb') as f:
        f.write(audio_data)
    return output_path

# 4. Creatomate 云端合成
def assemble_video(video_url, audio_url, dialogue_text):
    url = "https://api.creatomate.com/v1/renders"
    headers = {
        "Authorization": f"Bearer {CREATOMATE_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "source": {
            "output_format": "mp4",
            "elements": [
                {
                    "type": "video",
                    "source": video_url
                },
                {
                    "type": "audio",
                    "source": audio_url
                },
                {
                    "type": "text",
                    "text": dialogue_text,
                    "y": "85%"
                }
            ]
        }
    }
    res = requests.post(url, headers=headers, json=payload)
    return res.json()
```

## 🛠️ 进阶工程化建议 (Pitfalls & 实战经验)

1. **ElevenLabs 免费层风控机制**:
   如果在云服务器/代理环境下调用免费层 ElevenLabs，**100% 会被拦截**，返回 `401 detected_unusual_activity`。必须升级为基础付费计划($1)才能解封。若不想花钱，强烈建议全面切到阿里 CosyVoice。
2. **阿里百炼 TTS 接口乱象**:
   **不要自己构造 REST API POST 请求**。极易因为 endpoint 错综复杂而遭遇 `400 URL Error` 或 `403 AccessDenied`。**正确姿势**：使用官方 `dashscope` Python SDK 的 `SpeechSynthesizer` 模块。
3. **可灵国内版鉴权与 Endpoint**:
   - 国内版（使用 AK/SK）Endpoint 必须是 `openapi.klingai.com`，使用 `api.kuaishouzhineng.com` 或直接请求会报 DNS 或鉴权错误。
   - JWT 签名：`iss` 是 AK，秘钥是 SK，Header 必须指明 `"alg": "HS256", "typ": "JWT"`。
4. **可灵模型版本与参数冲突**:
   如果使用 `kling-v1-5` 并传递 `mode: std`，接口可能报错 `code 1201: mode std is not supported for model kling-v1-5`。遇到此问题，可将 `model_name` 降级为 `kling-v1` 即可顺利提交。
5. **异步轮询 (Polling)**:
   视频生成耗时极长，务必采取 **先并发提交所有 Prompt -> 保存 Task IDs -> 统一休眠轮询** 的策略。不要用阻塞式生成。
6. **CDN / 中转存储**:
   Creatomate 组装时，所用的素材 `source` 必须是直链公网可读的 URL。可灵生成的视频自带公网 URL，但你本地生成的 MP3 需要上传到一个图床/云存储（例如存到公开的 GitHub 仓库通过 `raw.githubusercontent.com` 调用）。