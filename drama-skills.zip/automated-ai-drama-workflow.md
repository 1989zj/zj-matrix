---
name: automated-ai-drama-workflow
description: 一套全自动化的 AI 短剧/预告片生成流水线，支持低成本 MVP（FFmpeg + Edge-TTS）与工业级 Pro（API 驱动）两种模式。
---

# Automated AI Drama Workflow

本技能提供从剧本到最终视频的全自动化实现方案，特别针对“无需人工干预”和“自定义主题”的需求。

## 1. 低成本 MVP 模式 (全免费/离线)
适用于快速验证想法或批量生成低成本内容。

### 核心架构
- **剧本**: LLM 输出 JSON (含对白、视觉关键词)。
- **配音**: `edge-tts` (微软免费接口)。
- **画面**: `loremflickr` 或 `Unsplash` 抓取静态图。
- **合成**: `ffmpeg` 使用 `zoompan` 滤镜将静态图转为动态视频。

### 关键代码 (FFmpeg Zoompan 技巧)
使用静态图生成电影感动效的关键命令：
```bash
ffmpeg -y -loop 1 -i input.jpg -i input.mp3 \
  -vf "scale=8000:-1,zoompan=z='zoom+0.0005':x=iw/2-(iw/zoom/2):y=ih/2-(ih/zoom/2):d=125:s=1080x1920,setsar=1" \
  -c:v libx264 -pix_fmt yuv420p -shortest output.mp4
```
*注：`zoom+0.0005` 控制缩放速度，值越大动作越快。*

### 自动化逻辑
1. 循环 JSON 剧本。
2. 为每一章生成音频和下载图片。
3. 执行上述 `ffmpeg` 命令生成镜头。
4. 使用 `ffmpeg concat` 合并所有镜头。

## 2. 工业级 Pro 模式 (付费 API)
适用于制作“电影预告片感”的高端内容。纯代码工作流请参考衍生技能 `auto-drama-api-pipeline`。

### 推荐工具栈
- **视频**: **Kling AI (可灵)** 或 **Runway Gen-3**。注意：可灵海外版(api.klingai.com) 与 国内版(openapi.kuaishou.com) 的鉴权方式和 endpoint 不同，且均需要保证账户拥有调用余额，免费层无法使用 API。
- **配音**: **ElevenLabs**。注意：在云服务器上通过 API 调用免费层的 ElevenLabs 会触发防滥用风控 (`Unusual activity detected. Free Tier usage disabled.`)，必须升级为付费计划，或者退而使用免费的 `edge-tts` 进行流水线跑通测试。国内平替推荐阿里 CosyVoice 或 火山引擎 TTS。
- **合成**: **Creatomate** 或 **Shotstack** API (云端自动剪辑、调色、加字幕)。Creatomate 测试十分友好，免费账户即可走通 auth 验证与渲染提交流程。

### 角色一致性流程 (Consistency)
1. **角色建模**: 先用 MJ/Flux 生成一张固定主角图。
2. **角色参考**: 将此图 URL 传给视频 API 的 `character_ref` 参数。
3. **分镜控制**: 脚本自动将 Claude 生成的 `camera_movement` 翻译为 API 的控制参数。

## 3. 常见坑点 (Pitfalls)
- **网络波动**: 自动化抓取图片时，建议准备 Fallback 方案（如生成纯色背景或重试机制）。
- **分支对齐**: 自动推送 GitHub 时，注意本地 `master` 与远程 `main` 的映射 (`git push origin master:main`)。
- **音频时长**: `ffmpeg` 合成时必须加 `-shortest` 确保视频长度与音频一致，否则会产生无限循环。
- **Markdown 渲染**: 在向用户展示复杂清单时，避免使用大面积表格，优先使用列表以防渲染截断。
