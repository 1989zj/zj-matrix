---
name: auto-drama-api-pipeline
description: 工业级纯代码驱动的 AI 短剧全自动生产流水线。整合 LLM (剧本) + 阿里百炼 CosyVoice (配音) + 国内版可灵 Kling (视频生成) + Creatomate (云端剪辑合成)，包含经过实战验证的 API 避坑指南。
---

# Auto Drama API Pipeline (工业级短剧全自动流水线)

这是一个纯代码驱动的“工业级”工作流，摒弃所有图形化编辑软件，通过 API 将短剧创作的核心环节（剧本、语音、画面、剪辑）串联起来。

根据实战测试，**强推使用国内版“可灵 API”配合“阿里百炼 CosyVoice SDK”**，以规避海外工具严格的免费层风控机制。

## 🎯 核心架构与 API 选型

1. **大脑 (LLM API)**: GPT-4o / Claude 3.5。生成包含 `visual_prompt` (强化电影级镜头语言描述) 和 `dialogue` 的 JSON 分镜。
2. **声音 (阿里百炼 CosyVoice)**: 国内最佳平替，使用官方 `dashscope` SDK，情绪饱满（如 `longxiaochun` 音色）。弃用 ElevenLabs 免费层以防云端风控。
3. **视觉 (可灵 Kling 国内版)**: 极具性价比与视觉张力，采用 AK/SK 生成 JWT 的鉴权方式。升级为 `pro` 模式，使用 `16:9` 比例，提升单镜头时长至 `10` 秒。
4. **缓存策略 (防重复调用)**: 建立本地 JSON 或 SQLite 缓存层，对生成的 Prompt 对应的视频 Task ID 和直链进行哈希缓存，避免相同镜头重复请求浪费资金。
5. **合成 (Creatomate API)**: 接收 JSON Payload 自动将生成的音视频对齐渲染。

## ⚙️ 环境变量准备

```bash
export KLING_AK="xxx"
export KLING_SK="xxx"
export ALIYUN_API_KEY="sk-xxx"
export CREATOMATE_API_KEY="xxx"
```

## 🚀 核心调度代码示例 (实战验证版)

```python
import os
import time
import requests
import jwt
import dashscope
from dashscope.audio.tts_v2 import SpeechSynthesizer

KLING_AK = os.getenv("KLING_AK")
KLING_SK = os.getenv("KLING_SK")
dashscope.api_key = os.getenv("ALIYUN_API_KEY")
CREATOMATE_KEY = os.getenv("CREATOMATE_API_KEY")

# 1. 可灵国内版 JWT 鉴权
def get_kling_token():
    payload = {
        "iss": KLING_AK,
        "exp": int(time.time()) + 1800,
        "nbf": int(time.time()) - 5
    }
    return jwt.encode(payload, KLING_SK, algorithm="HS256", headers={"alg": "HS256", "typ": "JWT"})

# 2. 提交可灵视频生成任务
def generate_video(prompt):
    url = "https://openapi.klingai.com/v1/videos/text2video"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {get_kling_token()}"
    }
    data = {
        "model_name": "kling-v1", # 避坑: kling-v1-5 可能不支持 mode: std
        "prompt": prompt,
        "mode": "pro", # 升级为 pro 模式提升细腻度
        "duration": "10", # 延长单镜头至 10 秒
        "ratio": "16:9" # 改为 16:9 获取更大画幅
    }
    res = requests.post(url, headers=headers, json=data)
    if res.status_code == 200:
        return res.json()['data']['task_id']
    return None

# 3. 阿里云 CosyVoice 配音 (必须用SDK)
def generate_audio(text, output_path):
    synthesizer = SpeechSynthesizer(model="cosyvoice-v1", voice="longxiaochun")
    audio_data = synthesizer.call(text)
    with open(output_path, 'wb') as f:
        f.write(audio_data)
    return output_path

# 4. Creatomate 云端合成
def assemble_video(video_url, audio_url, dialogue_text):
    url = "https://api.creatomate.com/v1/renders"
    headers = {
        "Authorization": f"Bearer {CREATOMATE_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "source": {
            "output_format": "mp4",
            "elements": [
                {
                    "type": "video",
                    "source": video_url
                },
                {
                    "type": "audio",
                    "source": audio_url
                },
                {
                    "type": "text",
                    "text": dialogue_text,
                    "y": "85%"
                }
            ]
        }
    }
    res = requests.post(url, headers=headers, json=payload)
    return res.json()
```

## 🛠️ 进阶工程化建议 (Pitfalls & 实战经验)

0. **极致控本 (防重复请求与缓存机制)**: 
   在实际开发中，视频 API 每次请求都在消耗真金白银。必须实现**本地缓存层**（如 `video_urls.json`）。在调用视频生成前，计算 prompt 的哈希值，命中则直接返回已有 CDN 链接。修改代码或调试其他组件（如音频、剪辑）时，这能节省 90% 以上的重复测试成本。
1. **ElevenLabs 免费层风控机制**:
   如果在云服务器/代理环境下调用免费层 ElevenLabs，**100% 会被拦截**，返回 `401 detected_unusual_activity`。必须升级为基础付费计划($1)才能解封。若不想花钱，强烈建议全面切到阿里 CosyVoice。
2. **阿里百炼 TTS 接口乱象**:
   **不要自己构造 REST API POST 请求**。极易因为 endpoint 错综复杂而遭遇 `400 URL Error` 或 `403 AccessDenied`。**正确姿势**：使用官方 `dashscope` Python SDK 的 `SpeechSynthesizer` 模块。
3. **可灵国内版鉴权与 Endpoint**:
   - 国内版（使用 AK/SK）Endpoint 必须是 `openapi.klingai.com`，使用 `api.kuaishouzhineng.com` 或直接请求会报 DNS 或鉴权错误。
   - JWT 签名：`iss` 是 AK，秘钥是 SK，Header 必须指明 `"alg": "HS256", "typ": "JWT"`。
4. **可灵模型版本与参数冲突**:
   如果使用 `kling-v1-5` 并传递 `mode: std`，接口可能报错 `code 1201: mode std is not supported for model kling-v1-5`。遇到此问题，可将 `model_name` 降级为 `kling-v1` 即可顺利提交。
5. **Creatomate 成功状态返回值解析坑点**:
   当提交给 Creatomate API 后如果返回 HTTP 200 OK，证明任务接收成功，但其 JSON **返回结构并不稳定**。有时是单个字典 `{ "id": "..." }`，有时是一个单元素数组 `[{ "id": "...", "status": "planned" }]`。如果代码只当作字典解析（如 `data.get("id")`）就会抛出运行时异常导致流程中断。**正确做法**：判断类型 `if isinstance(data, list): render_id = data[0].get("id")`，兼容处理。
6. **异步轮询 (Polling)**:
   视频生成耗时极长，务必采取 **先并发提交所有 Prompt -> 保存 Task IDs -> 统一休眠轮询** 的策略。不要用阻塞式生成。
7. **CDN / 中转存储**:
   Creatomate 组装时，所用的素材 `source` 必须是直链公网可读的 URL。可灵生成的视频自带公网 URL，但你本地生成的 MP3 需要上传到一个图床/云存储（例如存到公开的 GitHub 仓库通过 `raw.githubusercontent.com` 调用，**这也是实现“零成本”创收的核心操作**）。
8. **视频音频对齐 (Creatomate Freeze 策略)**:
   短剧的对白长度可能超过可灵生成的 5 秒视频。在 Creatomate API payload 中，通过获取实际音频时长（如使用 `ffprobe` 获取精确秒数），并在 video element 中设置 `"time_scale": "freeze"` 和明确的总体 `duration`。这样当视频播放完毕后，最后一帧会自动定格，直到音频播放结束。
9. **大模型自动扩写编剧 (Qwen)**:
   将 LLM API 接入作为第一步流水线。提供简单的创意脑洞（如“废柴修仙”），要求 LLM 严格返回包含 `video_prompt`（控制在50词内高质量英文以优化可灵生成）和 `dialogue`（带情绪的中文旁白）的 JSON 对象，消除人工编剧门槛。
10. **自动 BGM 混音与字幕动效烧录**:
   商业短剧中背景音效与字幕是不可或缺的。在 Creatomate 的 Payload 中，加入免版权公共音频链接，并将 `"audio_volume"` 压低至 30% 左右以免喧宾夺主。利用 text 元素生成字幕，设置高对比度样式（纯白字体 + 黑色描边/阴影，如 `"fill_color": "#ffffff", "stroke_color": "#000000", "stroke_width": "3px"`），同时配上 `"animations"` 属性加入 fade in/out 效果，无需人工打轴即可达到商业级的出片质感。
11. **本地 Gradio UI 封装**:
   针对商业化和运营需求，建议将零散的命令行操作封装为 Gradio Web UI。通过 `gr.Progress()` 提供进度反馈，方便无技术背景的运营人员一键提交提示词并预览/下载生成好的最终 MP4 短剧片段。