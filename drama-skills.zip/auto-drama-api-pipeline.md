---
name: auto-drama-api-pipeline
description: 工业级纯代码驱动的 AI 短剧全自动生产流水线。整合 LLM (剧本) + ElevenLabs (配音) + Kling/Runway (视频生成) + Creatomate (云端剪辑合成)，实现“输入主题，输出成片”的一键式工作流。
---

# Auto Drama API Pipeline (工业级短剧全自动流水线)

这是一个纯代码驱动的“工业级”工作流，摒弃所有图形化编辑软件（如剪映），通过 API 将短剧创作的四大核心环节（剧本、语音、画面、剪辑）完全串联起来。

## 🎯 核心架构与 API 选型

1. **大脑 (LLM API)**: 比如 OpenAI `GPT-4o` 或 `Claude 3.5 Sonnet`。负责根据用户一句话主题，输出极其严格的、富含镜头语言的 JSON 分镜脚本。
2. **声音 (ElevenLabs API)**: 负责将 JSON 中的 `dialogue` 转为极具情绪爆发力的高质量配音，并返回音频 URL。
3. **视觉 (Kling / Luma / Runway API)**: 负责接收 JSON 中的 `visual_prompt` 生成高质量动态视频。**进阶：** 传入固定的 `image_ref` URL 确保主角不换脸。
4. **合成 (Creatomate API)**: 最强大的云端基于 JSON 的视频渲染引擎。它负责将生成的音视频对齐、添加黑色淡入淡出转场、自动根据对白铺设字幕。

## ⚙️ 环境变量准备

运行此流水线前，你需要准备以下 API Keys 并配置在环境中：
```bash
export OPENAI_API_KEY="sk-xxx"
export ELEVENLABS_API_KEY="sk_xxx"
export KLING_API_KEY="xxx"  # 或其他视频模型API
export CREATOMATE_API_KEY="xxx"
```

## 🚀 核心调度代码：`drama_pipeline.py`

此脚本可以直接运行。它展示了如何调度四大平台的 API。

```python
import os
import json
import time
import requests
from concurrent.futures import ThreadPoolExecutor

class ProDramaPipeline:
    def __init__(self):
        # 检查必要的 API 密钥
        self.openai_key = os.getenv("OPENAI_API_KEY")
        self.elevenlabs_key = os.getenv("ELEVENLABS_API_KEY")
        self.creatomate_key = os.getenv("CREATOMATE_API_KEY")
        # 视频模型由于生态多变，以通用的 Webhook/Polling 逻辑展示
        self.video_api_key = os.getenv("VIDEO_API_KEY") 

    def step1_generate_script(self, topic: str) -> list:
        print(f"📝 阶段1：正在生成《{topic}》的结构化剧本...")
        headers = {
            "Authorization": f"Bearer {self.openai_key}",
            "Content-Type": "application/json"
        }
        prompt = f"""
        请为一个短剧创作剧本，主题为：{topic}。
        必须严格输出一个 JSON 数组，不要有任何 Markdown 标记，格式如下：
        [
          {{
            "scene_id": 1,
            "visual_prompt": "Cinematic 8k, tracking shot, a cyberpunk detective walking in heavy rain, neon lights.",
            "dialogue": "这是我来到这座城市的第三天，雨一直没停过。"
          }}
        ]
        生成 3-4 个分镜即可，保证剧情有起伏。
        """
        payload = {
            "model": "gpt-4o",
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.7,
            "response_format": { "type": "json_object" }
        }
        # 模拟请求或真实调用
        response = requests.post("https://api.openai.com/v1/chat/completions", json=payload, headers=headers)
        if response.status_code != 200:
            raise Exception(f"剧本生成失败: {response.text}")
        
        content = response.json()['choices'][0]['message']['content']
        # 为了容错，提取包裹在 JSON 中的内容
        return json.loads(content).get('scenes', json.loads(content))

    def step2_generate_audio(self, text: str, voice_id: str = "JBFqnCBcs6TW4GNdfsnA") -> str:
        print(f"🎙️ 阶段2：生成配音 - {text[:10]}...")
        url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
        headers = {
            "xi-api-key": self.elevenlabs_key,
            "Content-Type": "application/json"
        }
        data = {
            "text": text,
            "model_id": "eleven_multilingual_v2",
            "voice_settings": {"stability": 0.5, "similarity_boost": 0.75}
        }
        # 真实场景中，你会将音频流保存到本地或上传至 S3 获得 URL
        response = requests.post(url, json=data, headers=headers)
        # 此处假设我们有一步上传逻辑并返回 URL：
        audio_url = f"https://your-storage.com/audio/{hash(text)}.mp3" 
        return audio_url

    def step3_generate_video(self, prompt: str) -> str:
        print(f"🎥 阶段3：生成视频画面 - {prompt[:15]}...")
        # 伪代码：调用视频大模型 API (例如 Kling/Runway)
        # 典型流程是：提交 prompt -> 拿到 Task ID -> 轮询 Task 状态 -> 返回 MP4 URL
        time.sleep(2) # 模拟等待
        video_url = f"https://your-storage.com/video/{hash(prompt)}.mp4"
        return video_url

    def process_scene(self, scene: dict) -> dict:
        """并发处理单个分镜的声音和画面"""
        scene['audio_url'] = self.step2_generate_audio(scene['dialogue'])
        scene['video_url'] = self.step3_generate_video(scene['visual_prompt'])
        return scene

    def step4_assemble_in_cloud(self, scenes: list) -> str:
        print("🎬 阶段4：正在提交云端剪辑渲染...")
        url = "https://api.creatomate.com/v1/renders"
        headers = {
            "Authorization": f"Bearer {self.creatomate_key}",
            "Content-Type": "application/json"
        }
        
        # 构建 Creatomate Timeline (自动将视频片段串联，附加字幕)
        elements = []
        for i, scene in enumerate(scenes):
            track_element = {
                "type": "composition",
                "track": i + 1,
                "elements": [
                    {
                        "type": "video",
                        "source": scene['video_url']
                    },
                    {
                        "type": "audio",
                        "source": scene['audio_url']
                    },
                    {
                        "type": "text",
                        "text": scene['dialogue'],
                        "y": "85%", # 字幕位置
                        "fill_color": "#ffffff",
                        "shadow_color": "#000000",
                        "animations": [{"type": "fade", "time": "start", "duration": 0.5}]
                    }
                ]
            }
            elements.append(track_element)

        payload = {
            "source": {
                "output_format": "mp4",
                "frame_rate": 30,
                "width": 1080,
                "height": 1920, # 9:16 竖屏短剧
                "elements": elements
            }
        }
        
        # 真实场景中，调用 Creatomate 接口并等待渲染完成
        # response = requests.post(url, headers=headers, json=payload)
        # return response.json().get("url")
        print("✅ 云端剪辑指令已发送！")
        return "https://creatomate-renders.s3.amazonaws.com/your-final-drama.mp4"

    def run(self, topic: str):
        # 1. 剧本
        script = self.step1_generate_script(topic)
        print(f"✅ 获取到 {len(script)} 个分镜脚本。")
        
        # 2. 并发生成素材（节省极大的等待时间）
        print("⚡ 开始并发生成音视频素材...")
        with ThreadPoolExecutor(max_workers=5) as executor:
            completed_scenes = list(executor.map(self.process_scene, script))
            
        # 3. 合成组装
        final_video_url = self.step4_assemble_in_cloud(completed_scenes)
        
        print(f"\n🎉 全自动生成完毕！")
        print(f"👉 您的短剧下载链接: {final_video_url}")

if __name__ == "__main__":
    # 使用示例
    pipeline = ProDramaPipeline()
    # pipeline.run("赛博朋克世界里，一个发现自己是AI的杀手")
```

## 🛠️ 进阶工程化建议 (Pitfalls & Pro-tips)

1. **一致性增强 (Consistency)**: 在 `step3` 生成视频前，先调用一次 Midjourney/Flux API 生成主角设定图，获取 URL，作为 `image_ref` (Character Reference) 参数传递给视频 API，这样每个分镜出来的脸都是一样的。
2. **并行处理 (Concurrency)**: 上面的代码演示了使用 `ThreadPoolExecutor` 并发处理所有分镜的音频和视频。这是必须的，因为视频生成非常慢（可能 1-3 分钟），串行生成 10 个镜头会浪费大量时间。
3. **音视频时长对齐 (Duration Matching)**: 在向 Creatomate 提交 JSON 组装时，强烈建议开启音频驱动视频时长。如果音频长达 6 秒，但视频只有 5 秒，你需要告诉 Creatomate API 针对最后 1 秒 `time_scale` 设为 `freeze` (画面定格) 或者使用 `loop` 策略，防止画面黑屏。
4. **长短剧分块 (Chunking)**: 如果要生成 3 分钟以上的视频，建议将 JSON 脚本切分为多个 Part 渲染，最后再合并。直接渲染超大 JSON 容易导致云端内存溢出或超时。
5. **并发渲染容错机制 (Concurrent Polling)**: 可灵大模型的长视频生成常常长达 3-5 分钟且极易卡在队列里。最佳实践是**分离提交与轮询**：循环一圈先为所有分镜发送生成请求并记录下所有的 `task_id`，再进入下一个循环并发 `poll` 所有的任务状态。这样能将原来串行排队所需的总时长压缩 60% 以上。
5. **API 实战避坑与黑科技**: 
   - **ElevenLabs 风控**: 免费层 Key 如果在云服务器/代理环境下调用，极易触发 `detected_unusual_activity` 封禁，提示升级付费。必须升级为基础付费计划($1)才能解封 API 调用。
   - **阿里百炼 (CosyVoice)**: 强烈建议直接使用官方 `dashscope` Python SDK (如 `dashscope.audio.tts_v2.SpeechSynthesizer`)。自己构造 REST API POST 请求极易因为 endpoint 错综复杂而遭遇 400 URL Error 或 403 鉴权失败。注意：`longxiaochun` (年轻女性) 和 `sambert-zhichu-v1` 等常见音色组合通常能稳定返回 200，但如果不小心使用了不支持某些音色的 `cosyvoice-v1` 组合（如 `longfeiyu`），API 会返回 418 Error，导致长音频请求瞬间失败。建议正式跑批前对目标声音发一句短测试进行容错探测。使用阿里的语音大模型做短剧是首选，而不是 ElevenLabs。
   - **中转存储 (解决 Creatomate 直链痛点)**: 云端剪辑要求素材 URL 必须是公开直链。**千万不要**使用 `0x0.st` 或 `file.io` 等免费图床，它们极易返回带 Captcha 的 HTML 导致代码解析崩溃。**最佳零成本方案**：新建一个专门的 **Public GitHub 仓库** (如 `zj-drama-assets`)。脚本将生成的 mp3/mp4 用 git push 上去，拼接成 `https://raw.githubusercontent.com/...` 交给 Creatomate 渲染，完成后再自动 git rm 销毁。注意：绝对不能用 Private 仓库，其 raw 链接 Creatomate 无法读取。上传后，建议在代码中 `time.sleep(10)`，因为 GitHub CDN 的 `raw.githubusercontent.com` 更新存在轻微的缓存延迟，立即提交给 Creatomate 可能会遭遇 404 错误。
